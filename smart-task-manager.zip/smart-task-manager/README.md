# Smart Task Manager

A small task manager: sign up, sign in, add tasks with a priority, tick them off, delete them.
Admins can see everyone's tasks. Built with React, Express, MongoDB, Docker and Nginx.

## Run the tests
```bash
cd server && npm install && npm test     # 22 API tests, no database needed
cd client && npm install && npm test     # 19 page tests
```

## Option A: run it on your GCP VM (easiest, nothing to install on your laptop)
1. Click **UPLOAD FILE** at the top of the SSH-in-browser window and choose the zip. It lands in your home folder.
2. In the SSH window:
```bash
sudo apt install -y unzip curl
unzip smart-task-manager-v4.zip
cd smart-task-manager
curl -fsSL https://get.docker.com | sudo sh
sudo usermod -aG docker $USER
```
3. Close the SSH window and open it again (this lets your user run Docker), then:
```bash
cd ~/smart-task-manager
./scripts/init-env.sh              # makes .env with random secrets
docker compose up -d --build       # first build takes several minutes on a small VM
docker compose ps                  # api, mongo, web should be running
```
4. In the GCP console, copy the VM's **External IP** and open `http://<that IP>` in your browser.
   (If it doesn't load: the VM needs "Allow HTTP traffic" ticked.)

## Option B: run it on your laptop with Docker Desktop
Install Docker Desktop, open a terminal in the project folder, then:
```bash
cp .env.example .env        # Windows PowerShell: copy .env.example .env
```
Edit `.env`: set `MONGO_PASSWORD` (letters and numbers only) and `JWT_SECRET` (32+ random characters).
```bash
docker compose up -d --build
```
Open http://localhost

## Everyday commands
```bash
docker compose ps               # what is running
docker compose logs -f api      # watch the API logs
docker compose restart api
docker compose down             # stop (your data is kept)
```

## Make an admin
Register normally, then:
```bash
source .env
docker compose exec mongo mongosh -u "$MONGO_USER" -p "$MONGO_PASSWORD" --authenticationDatabase admin smart-task-manager \
  --eval 'db.users.updateOne({email:"you@example.com"},{$set:{role:"admin"}})'
```
Sign out and back in to see the admin view.

## HTTPS (needs a domain name pointing at the VM)
```bash
./scripts/enable-https.sh yourname.duckdns.org you@email.com
```
Certificates renew automatically.

## Backups
```bash
./scripts/backup.sh                       # run once by hand to test
crontab -e                                # add: every day at 02:00
0 2 * * * /home/<your-user>/smart-task-manager/scripts/backup.sh >> /home/<your-user>/backup.log 2>&1
./scripts/restore.sh backups/<file>.archive.gz     # restore a backup
```
The newest 7 backups are kept in `./backups`. Copy them off the VM now and then.

## Automatic deploys
Add the repository secrets `VM_HOST`, `VM_USER`, `VM_SSH_KEY`. Each push to `main` runs the tests,
then deploys to the VM with `git pull` and `docker compose up -d --build`.

## How it works
- **Sign-in:** passwords are checked on the page and again on the server, stored as bcrypt hashes, and
  login returns a JWT that the API checks on every request. Wrong email and wrong password give the same
  message, and repeated failed logins are rate limited.
- **Roles:** a user sees only their own tasks. An admin sees all of them, with the owner's name.
- **Deployment:** Nginx serves the React app and forwards `/api` to the Node API. MongoDB is only
  reachable from inside Docker.

```
server/    API (routes, models, middleware, tests)
client/    React app (Auth.jsx = sign-in, Tasks.jsx = task page, tests)
nginx/     Nginx configs (HTTP now, HTTPS template)
scripts/   init-env.sh, enable-https.sh, backup.sh, restore.sh
docker-compose.yml
```
